#/bin/sh
###########################################################################
###########################################################################
###########################################################################
###########################################################################
################### dA MODIFICARE #########################################
###########################################################################
###########################################################################
###########################################################################
###########################################################################


TIMEOUT=15
if [ -f /usr/bin/startx ]; then
        while ! [ -f /tmp/system_ready ]; do
                sleep 1
                let TIMEOUT=${TIMEOUT}-1
                if [ "${TIMEOUT}" == "0" ]; then
                        break
                fi
        done
        kill -HUP `pidof X` >/dev/null 2>&1
        kill -HUP `pidof x11vnc` >/dev/null 2>&1
        export DISPLAY=":0.0"
        /usr/bin/startx &
        if [ -f /tmp/application_storage/bkgwm.png ]; then
                sleep 1
                fbsetbg -c /tmp/application_storage/bkgwm.png
        fi
fi


# 120 secs max timeout communication at startup
TIMEOUTTCMS=0
WAITTIME=`cat /tmp/setup_boot | grep WAIT_TIME_FOR_COMMUNICATIONS | sed 's/WAIT_TIME_FOR_COMMUNICATIONS=//g'`
while [ ! -f /tmp/www/POST_enable ]; do
        sleep 1
	let COUNT=$COUNT+1
	if [ "$COUNT" -ge "$WAITTIME" ]; then
		TIMEOUTTCMS=1
		break
	fi
done

# Timeout management with ERROR TYPE 1
#/tmp/www/cgi-bin/find_lvds
if [ "$TIMEOUTTCMS" = "0" ]; then
	/tmp/www/POST_GreenSquare `cat /tmp/setup_boot | grep TCMS_GREEN_SQUARE_TIME | sed 's/TCMS_GREEN_SQUARE_TIME=//g'`
else
	kill -HUP `pidof GDSBT_iptcom` >/dev/null 2>&1
	kill -HUP `pidof auto_backlight_bkg` >/dev/null 2>&1
	kill -HUP `pidof monitor_counter` >/dev/null 2>&1
	kill -HUP `pidof backlight_counter` >/dev/null 2>&1
	/tmp/www/GdsScreenTest &
	sleep 1
        /tmp/www/GdsScreenTestWrite START
	sleep 1
	/tmp/www/GdsScreenTestWrite DIAG
	sleep 1
	exit 0
fi