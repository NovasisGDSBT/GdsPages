#!/bin/sh
DATE=`date -u`
echo "$DATE : $1 $2 $3 $4" >> /tmp/gds_log 
